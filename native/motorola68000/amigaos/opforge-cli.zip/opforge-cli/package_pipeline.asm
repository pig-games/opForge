; Native AmigaOS opForge CLI shell.
;
; This first slice mirrors the Rust CLI argument names for a strict native
; subset and provides deterministic stage stubs until parser/emitter VMs exist
; on AmigaOS.

	.module opforge.cli.package_pipeline
	.cpu 68020

	.use opforge.cli.constants (PACKAGE_INPUT_PTR_V1, LAST_ERROR_BUFFER_PTR_V1) 
	.use opforge.cli.copy (*)
	.use tkpkg.amigaos.service (tkpkgServiceDispatchV1)
	.use tkpkg.amigaos.buffers (LAST_ERROR_BUFFER_PTR_V1)

	.use tkpkg.amigaos.abi (ENTRY_ORD_INIT, ENTRY_ORD_LOAD_PACKAGE)

	.use opforge.cli.tkpkg_control_block (opforgeNativeCliReadStatus, opforgeNativeCliWriteInputWindow)

	.section code, kind=code
	.pub

; Initialize tkpkg, stage/load package bytes, and select the requested pipeline.
opforgeNativeCliInitPackagePipeline .block
	lea ControlBlockV1, a0
	moveq #ENTRY_ORD_INIT, d0
	jsr tkpkgServiceDispatchV1
	jsr opforgeNativeCliReadStatus
	tst.b d0
	bne.w fail

	bsr.w opforgeNativeCliStagePackage
	tst.l d0
	bne.w fail

	lea ControlBlockV1, a0
	move.w #PACKAGE_INPUT_PTR_V1, d0
	move.w NativeCliPackageLenActive, d1
	jsr opforgeNativeCliWriteInputWindow
	moveq #ENTRY_ORD_LOAD_PACKAGE, d0
	jsr tkpkgServiceDispatchV1
	bsr.w opforgeNativeCliReadStatus
	tst.b d0
	bne.s fail

	bsr.w opforgeNativeCliPreparePipelineRequest
	tst.l d0
	bne.s fail

	lea ControlBlockV1, a0
	move.w #LAST_ERROR_BUFFER_PTR_V1, d0
	move.w NativeCliPipelineRequestLen, d1
	jsr opforgeNativeCliWriteInputWindow
	moveq #ENTRY_ORD_SET_PIPELINE, d0
	jsr tkpkgServiceDispatchV1
	jsr opforgeNativeCliReadStatus
	tst.b d0
	bne.s fail
	moveq #0, d0
	rts

fail
	moveq #1, d0
	rts
	.bend ; opforgeNativeCliInitPackagePipeline


; Stage either the embedded package or an external --opasm-package file.
opforgeNativeCliStagePackage .block
	tst.b NativeCliPackagePath
	bne.s opforgeNativeCliStageExternalPackage

	lea opforgeNativeCliPackageData, a1
	lea packageStorage, a2
	move.w OpforgeNativeCliPackageLen, d0
	move.w d0, NativeCliPackageLenActive
	jsr opforgeNativeCliCopyBytes
	moveq #0, d0
	rts
	.bend ; opforgeNativeCliStagePackage

; Build the tkpkg set-pipeline request payload from --cpu or the default CPU.
opforgeNativeCliPreparePipelineRequest .block
	lea NativeCliCpuName, a0
	tst.b (a0)
	bne.s haveCpu
	lea DefaultCpuName, a0

haveCpu
	lea lastErrorBuffer, a1
	jsr opforgeNativeCliCopyCString
	move.w d0, NativeCliPipelineRequestLen
	moveq #0, d0
	rts
	.bend ; opforgeNativeCliPreparePipelineRequest

	.endsection
	.endmodule
