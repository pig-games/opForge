; Native AmigaOS opForge CLI shell.
;
; This first slice mirrors the Rust CLI argument names for a strict native
; subset and provides deterministic stage stubs until parser/emitter VMs exist
; on AmigaOS.

	.module opforge.cli.source_reader
	.cpu 68020

	.use opforge.cli.state (NativeCliInputChar, NativeCliDosBase, NativeCliInputPath)
	.use opforge.cli.state (NativeCliPackageLenActive, NativeCliSourceLineNum, NativeCliSourceLineLen)
	.use opforge.cli.state (NativeCliSawCr, NativeCliIncludeDepth, NativeCliModuleResolveDepth)
	.use opforge.cli.state (NativeCliModuleDepth)
	.use opforge.cli.constants (PACKAGE_INPUT_PTR_V1, SOURCE_LINE_BUFFER_CAPACITY) 
	.use opforge.cli.strings (TokenizerOkText, ModuleDepthFailureText)
	.use opforge.cli.dos (opforgeNativeCliPutStr, opforgeNativeCliOpenInput)
	.use opforge.cli.dos (opforgeNativeCliReadInput, opforgeNativeCliClose)
	.use opforge.cli.copy (*)
	.use opforge.cli.path (opforgeNativeCliCopyPathBuffer)
	.use tkpkg.amigaos.service (tkpkgServiceDispatchV1)
	.use tkpkg.amigaos.buffers (LAST_ERROR_BUFFER_PTR_V1)

	.use tkpkg.amigaos.abi (ENTRY_ORD_INIT, ENTRY_ORD_LOAD_PACKAGE)

	.use opforge.cli.package_pipeline (opforgeNativeCliPreparePipelineRequest)
	.use opforge.cli.line_processor (opforgeNativeCliParseCurrentLine)
	.use opforge.cli.tkpkg_control_block (opforgeNativeCliReadStatus, opforgeNativeCliReadOutputLen, opforgeNativeCliWriteInputWindow)

	.section code, kind=code
	.pub

; Initialize package state, tokenize every source line, and run parser routing.
opforgeNativeCliTokenizeFrontend .block
	movem.l d2-d7/a2-a6, -(sp)
	bsr.w opforgeNativeCliInitPackagePipeline
	tst.l d0
	bne.b return
	move.l #TokenizerOkText, d1
	jsr opforgeNativeCliPutStr
	bsr.w opforgeNativeCliTokenizeFile
	tst.l d0
	bne.s return

success
	moveq #0, d0

return
	movem.l (sp)+, d2-d7/a2-a6
	rts
	.bend ; opforgeNativeCliTokenizeFrontend

; Tokenize the primary input file path recorded by argument parsing.
opforgeNativeCliTokenizeFile .block
	lea NativeCliInputPath, a0
	lea NativeCliCurrentPath, a1
	jsr opforgeNativeCliCopyPathBuffer
	tst.l d0
	bne.s fail
	lea NativeCliInputPath, a0
	bsr.w opforgeNativeCliTokenizeFileAtPath
	rts

fail
	moveq #1, d0
	rts
	.bend ; opforgeNativeCliTokenizeFile

; Read and tokenize one AmigaDOS text file at A0, preserving logical line state.
opforgeNativeCliTokenizeFileAtPath .block
	jsr opforgeNativeCliOpenInput
	tst.l d0
	bne.s openOk
	moveq #1, d0
	rts

openOk
	move.l d0, d5
	move.l #1, NativeCliSourceLineNum
	clr.w NativeCliSourceLineLen
	clr.w NativeCliSawCr

loop
	lea NativeCliInputChar, a0
	moveq #1, d0
	move.l d5, d1
	jsr opforgeNativeCliReadInput
	cmp.l #-1, d0
	beq.w close
	tst.l d0
	beq.w fileEof

	move.b NativeCliInputChar, d0
	tst.w NativeCliSawCr
	beq.s checkBreak
	clr.w NativeCliSawCr
	cmpi.b #10, d0
	beq.w loop

checkBreak
	cmpi.b #10, d0
	beq.s lineDone
	cmpi.b #13, d0
	beq.s crDone

	move.w NativeCliSourceLineLen, d1
	cmpi.w #SOURCE_LINE_BUFFER_CAPACITY, d1
	bhs.w close
	lea NativeCliSourceLine, a1
	move.b d0, 0(a1, d1.W)
	addq.w #1, d1
	move.w d1, NativeCliSourceLineLen
	bra.w loop

crDone
	move.w #1, NativeCliSawCr

lineDone
	jsr opforgeNativeCliTokenizeCurrentLine
	tst.l d0
	bne.s close
	move.l NativeCliSourceLineNum, d0
	addq.l #1, d0
	move.l d0, NativeCliSourceLineNum
	clr.w NativeCliSourceLineLen
	bra.w loop

fileEof
	tst.w NativeCliSourceLineLen
	beq.s checkModuleDepth
	jsr opforgeNativeCliTokenizeCurrentLine
	tst.l d0
	bne.s close

checkModuleDepth
	tst.w NativeCliIncludeDepth
	bne.s successClose
	tst.w NativeCliModuleResolveDepth
	bne.s successClose
	tst.w NativeCliModuleDepth
	beq.s successClose
	move.l #ModuleDepthFailureText, d1
	jsr opforgeNativeCliPutStr
	bra.s close

successClose
	move.l d5, d1
	jsr opforgeNativeCliClose
	moveq #0, d0
	rts

close
	move.l d5, d1
	jsr opforgeNativeCliClose
	moveq #1, d0
	rts
	.bend ; opforgeNativeCliTokenizeFileAtPath

	.endsection
	.endmodule
